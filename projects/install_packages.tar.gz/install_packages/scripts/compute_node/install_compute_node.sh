#!/bin/sh

stty sane
echo /tmp/install_compute_node.log.$$ > /tmp/install_compute_node.log.$$ 2>&1

sudo apt-get -y update >> /tmp/install_compute_node.log.$$ 2>&1
sudo apt-get -y upgrade >> /tmp/install_compute_node.log.$$ 2>&1
sudo apt-get -y update >> /tmp/install_compute_node.log.$$ 2>&1
sudo apt-get -y autoremove >> /tmp/install_compute_node.log.$$ 2>&1

# Assume a folder ~/Downloads/install_packages exists, there folder contains
# all the install scripts and source pakcages and configuration files 
# Assume ~/Downloads/install_packages/slurm-17.02.9.tar.bz2 exists

cd ~/Downloads/install_packages/
tar xvjf slurm-17.02.9.tar.bz2
cd slurm-17.02.9
./configure --prefix=/tmp/slurm-build --sysconfdir=/etc/slurm --enable-pam --with-pam_dir=/lib/x86_64-linux-gnu/security/
make
make contrib
sudo make install

# NFS install, compute node
sudo apt-get -y install nfs-client >> /tmp/install_compute_node.log.$$ 2>&1

sudo apt-get -y upgrade >> /tmp/install_compute_node.log.$$ 2>&1
sudo apt-get -y update >> /tmp/install_compute_node.log.$$ 2>&1
sudo apt-get -y autoremove >> /tmp/install_compute_node.log.$$ 2>&1