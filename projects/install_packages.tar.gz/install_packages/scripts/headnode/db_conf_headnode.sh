#!/bin/sh

stty sane
echo /tmp/db_conf.log.$$ > /tmp/db_conf.log.$$ 2>&1

sudo systemctl enable mysql >> /tmp/db_conf.log.$$ 2>&1
sudo systemctl start mysql >> /tmp/db_conf.log.$$ 2>&1

# do the following manually, basic database setup, create a dababase and a table, grant privileges
sudo mysql -u root <<EOF
create database if not exists slurm_acct_db;
create user if not exists 'slurm'@'localhost';
set password for 'slurm'@'localhost' = password('slurmdbpass');
grant usage on *.* to 'slurm'@'localhost';
grant all privileges on slurm_acct_db.* to 'slurm'@'localhost';
flush privileges;
exit
EOF